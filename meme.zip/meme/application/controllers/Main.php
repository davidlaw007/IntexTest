<?php
defined('BASEPATH') OR exit('No direct script access allowed');
header('Content-Type: application/json'); 

include('simple_html_dom.php');
class Main extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$url = "http://interview.funplay8.com/";

		$html = file_get_html($url);

		$pages = array();

		foreach($html->find('.pagination') as $page)
		{
			foreach($page->find('a') as $a)
			{
				$pages[] = $a->attr['href'];
			}
			$filter_pages = array_slice($pages, 1, -1);
			// print_r($pages);
		}

		$product_array = array();

		$id=1;

		$pageNumber = 1;

		$requestCount = 81;

		foreach($filter_pages as $indiviPage)
		{
			$indiviUrl = "http://interview.funplay8.com/" .$indiviPage;

			$html = file_get_html($indiviUrl);

			foreach($html->find('.well') as $div)
			{
				foreach($div->find('.col-sm-4') as $col)
				{
					foreach($col->find('.meme-img') as $img)
					{
						$imageUrl = $img->attr['src'];
						// echo $imageUrl ."<br>";
					}

					foreach($col->find('h6') as $text)
					{
						$name = $text->plaintext;
						// echo $name ."<br>";
					}
					
					if($requestCount == 0 ){

						$product_array[] = ([
							"id" => $id,
							"name" => $name,
							"url" => $imageUrl,
							"page" => $pageNumber,
							"requestCount" => 0
						]);

						$id++;
					} else{

						$product_array[] = ([
							"id" => $id,
							"name" => $name,
							"url" => $imageUrl,
							"page" => $pageNumber,
							"requestCount" => $requestCount
						]);

						$id++;
						$requestCount--;
					}
				}		
			}

			$pageNumber++;
		}

		$json_format = json_encode($product_array);

		$this->session->set_flashdata('item', $json_format);
	}

	public function index()
	{
		
		$var = $this->session->flashdata('item');
	
		print_r($var);

		$this->load->view('templates/header.php');
		$this->load->view('all.php');
		$this->load->view('templates/footer.php');

	}

	public function fetch_id($id)
	{
		$var = $this->session->flashdata('item');
	
		$decode_json = json_decode($var);

		foreach($decode_json as $data)
		{
			if($data->id == $id)
			{
				$json_result = json_encode($data);
				print_r($json_result);
			}
		}
		$this->load->view('templates/header.php');
		$this->load->view('fetch.php');
		$this->load->view('templates/footer.php');
	}

	public function fetch_page($page)
	{
		$var = $this->session->flashdata('item');
	
		$decode_json = json_decode($var);

		$search_page = array();

		foreach($decode_json as $data)
		{
			if($data->page == $page)
			{
				$search_page[] = array($data);
			}
		}

		$json_result = json_encode($search_page);
		
		print_r($json_result);

		$this->load->view('templates/header.php');
		$this->load->view('fetch.php');
		$this->load->view('templates/footer.php');
	}

	public function fetch_popular()
	{
		$var = $this->session->flashdata('item');

		$decode_json = json_decode($var);

		$most_item;
		$most_number = 0;

		foreach($decode_json as $k)
		{
			if($k->requestCount > $most_number)
			{
				$most_number = $k->requestCount;
				$most_item = $k;
			}
		}
		$json_result = json_encode($most_item);
		print_r($json_result);
	}

	public function create()
	{
		$this->load->view('templates/header.php');
		$this->load->view('create.php');
		$this->load->view('templates/footer.php');
	}

	public function submit()
	{
		$decode_json = array(); 
		$var = $this->session->flashdata('item');

		$decode_json = json_decode($var);
		
		$id = array_column($decode_json, 'id');
		$endid = end($id); //852

		$insert_array = array();

		for($i=0; $i<count($_POST['name']); $i++)
		{
			$page = array_column($decode_json, 'page');
			$endpage = end($page); //95

			$numItemInPage = array_count_values(array_column($decode_json, 'page'))[$endpage];
			// echo $numItemInPage; //6
			// print_r($page);

			$endid++;

			if($numItemInPage != 9)
			{
				$decode_json[] = ([
					"id" => $endid,
					"name" => $_POST['name'][$i],
					"url" => $_POST['url'][$i],
					"page" => $endpage,
					"requestCount" => 0
				]);
				
			} else{
				$endpage++;

				$decode_json[] = ([
					"id" => $endid,
					"name" => $_POST['name'][$i],
					"url" => $_POST['url'][$i],
					"page" => $endpage,
					"requestCount" => 0
				]);
			}	
		}
		$json_result = json_encode($decode_json);
		print_r($json_result);
	}
}

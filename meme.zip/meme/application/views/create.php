
<?php $attributes = array("name" => "addImageForm");
	echo form_open_multipart("Main/submit", $attributes); ?>
	<h6>INSERT NEW IMAGES</h6>
		<div class="form-group">
            <label for="image" class="control-label mb-1 font-weight-bold">Image(s)</label>
            <table id="item_table" class="table table-striped table-bordered" cellspacing="0" width="100%">
              <tr>
                <th>Name</th>
                <th>Public Url</th>
                <th>Action</th>
              </tr>
              <tr>
                <td><input type="text" name="name[]" class="form-control form-control-inline" required /></td>
                <td><input type="text" name="url[]" class="form-control form-control-inline" required /></td>
                <td><button type="button" name="remove" class="btn remove"><span class="input-group-text"><i class="fa fa-times " aria-hidden="true"></i></span></button></td>
              </tr>
            </table>
            <button type="button" name="add" class="btn btn-outline-success add">Add Item</button>
          </div>
		  	<button type="submit" class="btn btn-primary">Submit</button>
		
	<?php echo form_close(); ?>

	<script type="text/javascript">
		$(document).ready(function(){

			$(document).on('click', '.add', function(){
				var html ='';
				html += '<tr>';
	          	html += '<td><input type="text" name="name[]" class="form-control form-control-inline" required/></td>';
	          	html += '<td><input type="text" name="url[]" class="form-control form-control-inline" required/></td>';
	          	html += '<td><button type="button" name="remove" class="btn remove"><span class="input-group-text"><i class="fa fa-times" aria-hidden="true"></i></span></button></td></tr>';
	          	$('#item_table').append(html);
			});

			$(document).on('click', '.remove', function(){
          		$(this).closest('tr').remove();
        	});
		});
	</script>